import { AUTHORITATIVE_OUTFITS } from '../config/catalog.js';

export class PaymentVerificationService {
  constructor() {
    this.providerMode = process.env.PAYMENT_PROVIDER_MODE || 'disabled';
    this.streamlabsTipUrl = process.env.STREAMLABS_TIP_URL || 'https://streamlabs.com/kiraplays_yt/tip';
  }

  getCheckoutStatusForOutfit(outfitId) {
    const outfit = AUTHORITATIVE_OUTFITS[outfitId];
    if (!outfit || (outfit.tier !== 'Iconic' && outfit.tier !== 'Mysterious')) {
      throw new Error('INVALID_PAID_OUTFIT_ID');
    }

    return {
      outfitId: outfit.id,
      outfitName: outfit.name,
      tier: outfit.tier,
      priceINR: outfit.priceINR,
      priceUSD: outfit.priceUSD,
      streamlabsTipUrl: this.streamlabsTipUrl,
      providerMode: this.providerMode,
      purchasesEnabled: false,
      securityNotice:
        'Automatic paid outfit unlocks are currently disabled for security. Streamlabs tip pages do not provide signed per-product checkout webhooks, so clicking "Verify" will not unlock paid outfits until a verified payment gateway is configured.'
    };
  }

  async verifyPremiumPurchaseAttempt(_userId, outfitId) {
    const outfit = AUTHORITATIVE_OUTFITS[outfitId];
    if (!outfit || (outfit.tier !== 'Iconic' && outfit.tier !== 'Mysterious')) {
      return {
        verified: false,
        code: 'INVALID_PAID_OUTFIT_ID',
        message: 'This outfit is not a valid store item.'
      };
    }

    return {
      verified: false,
      code: 'PAYMENT_VERIFICATION_UNAVAILABLE',
      message:
        'Unverified unlock blocked by server: Streamlabs tips cannot be cryptographically bound to a specific outfit purchase. Premium outfit purchases remain safely disabled until a signed webhook payment provider is configured.'
    };
  }
}

export const paymentService = new PaymentVerificationService();
