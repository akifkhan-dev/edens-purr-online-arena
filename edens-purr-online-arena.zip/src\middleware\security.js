import crypto from 'node:crypto';
import cookie from 'cookie';
import rateLimit from 'express-rate-limit';
import { db } from '../db/database.js';

const COOKIE_NAME = 'edens_purr_sid';
const SECRET = process.env.SESSION_SECRET || 'dev_fallback_secret_change_in_production_64_chars_minimum_0000';

export function signSessionToken(rawToken) {
  const mac = crypto.createHmac('sha256', SECRET).update(rawToken).digest('base64url');
  return `${rawToken}.${mac}`;
}

export function verifySignedSessionToken(signedCookie) {
  if (!signedCookie || typeof signedCookie !== 'string') return null;
  const parts = signedCookie.split('.');
  if (parts.length !== 2) return null;
  const [rawToken, mac] = parts;
  const expectedMac = crypto.createHmac('sha256', SECRET).update(rawToken).digest('base64url');
  const a = Buffer.from(mac);
  const b = Buffer.from(expectedMac);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  return rawToken;
}

export function hashRawToken(rawToken) {
  return crypto.createHash('sha256').update(rawToken).digest('hex');
}

export async function sessionMiddleware(req, res, next) {
  try {
    const rawCookieHeader = req.headers.cookie || '';
    const parsedCookies = cookie.parse(rawCookieHeader);
    const signedToken = parsedCookies[COOKIE_NAME];
    const rawToken = verifySignedSessionToken(signedToken);

    let userId = null;
    if (rawToken) {
      const tokenHash = hashRawToken(rawToken);
      userId = await db.getUserIdBySessionHash(tokenHash);
    }

    if (!userId) {
      const newRawToken = crypto.randomBytes(32).toString('base64url');
      const tokenHash = hashRawToken(newRawToken);
      const profile = await db.createGuestUserAndSession(
        tokenHash,
        req.headers['user-agent'] || '',
        req.ip || ''
      );
      userId = profile.userId;

      const isProd = process.env.NODE_ENV === 'production';
      res.setHeader(
        'Set-Cookie',
        cookie.serialize(COOKIE_NAME, signSessionToken(newRawToken), {
          httpOnly: true,
          secure: isProd,
          sameSite: 'lax',
          path: '/',
          maxAge: 60 * 60 * 24 * 90
        })
      );
      req.userProfile = profile;
      req.userId = userId;
      return next();
    }

    req.userId = userId;
    req.userProfile = await db.getFullProfileByUserId(userId);
    return next();
  } catch (err) {
    console.error('[AUTH ERROR]', err);
    return res.status(500).json({ error: 'SESSION_INIT_FAILED' });
  }
}

export async function authenticateSocketHandshake(handshake) {
  const rawCookieHeader = handshake.headers?.cookie || '';
  const parsed = cookie.parse(rawCookieHeader);
  const signedToken = parsed[COOKIE_NAME];
  const rawToken = verifySignedSessionToken(signedToken);
  if (!rawToken) return null;
  const tokenHash = hashRawToken(rawToken);
  return db.getUserIdBySessionHash(tokenHash);
}

export const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'TOO_MANY_REQUESTS' }
});

export const strictMutationLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 40,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'RATE_LIMIT_EXCEEDED' }
});
