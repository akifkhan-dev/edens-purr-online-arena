import pg from 'pg';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  AUTHORITATIVE_OUTFITS,
  VALID_BREED_IDS,
  VALID_HAT_IDS,
  VALID_REGIONS,
  VALID_CURRENCIES
} from '../config/catalog.js';

const { Pool } = pg;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

class DatabaseRepository {
  constructor() {
    this.pool = null;
    this.usePostgres = false;
    this.memory = {
      users: new Map(),
      sessions: new Map(),
      profiles: new Map(),
      entitlements: new Map(),
      orders: new Map(),
      transactions: new Map(),
      auditLogs: []
    };
    this._mutex = Promise.resolve();
  }

  async init() {
    const dbUrl = process.env.DATABASE_URL?.trim();
    const isProd = process.env.NODE_ENV === 'production';

    if (dbUrl && !dbUrl.includes('your_project_ref')) {
      this.pool = new Pool({
        connectionString: dbUrl,
        ssl: dbUrl.includes('localhost') || dbUrl.includes('127.0.0.1')
          ? false
          : { rejectUnauthorized: false },
        max: 15,
        idleTimeoutMillis: 30000
      });
      await this.runMigrations();
      this.usePostgres = true;
      console.log('[DB] Connected to PostgreSQL and verified schema migrations.');
    } else {
      if (isProd) {
        throw new Error('[DB FATAL] DATABASE_URL is required when NODE_ENV=production.');
      }
      console.warn('[DB] No DATABASE_URL configured; using transactional in-memory store for local dev/testing.');
    }
  }

  async runMigrations() {
    if (!this.pool) return;
    const sqlPath = path.join(__dirname, 'migrations', '001_initial_schema.sql');
    const sql = fs.readFileSync(sqlPath, 'utf8');
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(sql);
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  }

  async _withMemoryLock(fn) {
    const prev = this._mutex;
    let release;
    this._mutex = new Promise(resolve => { release = resolve; });
    await prev;
    try {
      return await fn();
    } finally {
      release();
    }
  }

  generateFriendCode() {
    return 'PURR-' + crypto.randomInt(1000, 9999);
  }

  async createGuestUserAndSession(tokenHash, userAgent = '', ipAddress = '') {
    const userId = crypto.randomUUID();
    const friendCode = this.generateFriendCode();
    const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 90);

    if (this.usePostgres) {
      const client = await this.pool.connect();
      try {
        await client.query('BEGIN');
        await client.query(`INSERT INTO users (id, account_type) VALUES ($1, 'guest')`, [userId]);
        await client.query(
          `INSERT INTO auth_sessions (token_hash, user_id, user_agent, ip_address, expires_at) VALUES ($1, $2, $3, $4, $5)`,
          [tokenHash, userId, userAgent, ipAddress, expiresAt]
        );
        await client.query(`INSERT INTO player_profiles (user_id, friend_code) VALUES ($1, $2)`, [userId, friendCode]);
        await client.query(`INSERT INTO outfit_entitlements (user_id, outfit_id, source) VALUES ($1, 'none', 'starter')`, [userId]);
        await client.query('COMMIT');
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      } finally {
        client.release();
      }
      return this.getFullProfileByUserId(userId);
    }

    return this._withMemoryLock(async () => {
      this.memory.users.set(userId, { id: userId, accountType: 'guest', email: null, passwordHash: null, createdAt: new Date() });
      this.memory.sessions.set(tokenHash, { tokenHash, userId, expiresAt });
      this.memory.profiles.set(userId, {
        userId,
        name: 'SmokeyPurr',
        friendCode,
        level: 1,
        walletPoints: 350,
        totalKOs: 0,
        selectedBreed: 'smokey',
        selectedOutfit: 'none',
        selectedHat: 'crown',
        useCustomColors: false,
        customEyeLeft: '#ffbf36',
        customEyeRight: '#4cd98c',
        serverRegion: 'global',
        currency: 'INR',
        friends: [],
        sfxEnabled: true,
        musicEnabled: true,
        vibrationEnabled: true,
        sfxVolume: 85,
        musicVolume: 70,
        inActiveMatch: false,
        pendingDisconnectPenalty: false
      });
      this.memory.entitlements.set(userId, new Set(['none']));
      return this.getFullProfileByUserId(userId);
    });
  }

  async getUserIdBySessionHash(tokenHash) {
    if (!tokenHash) return null;
    if (this.usePostgres) {
      const res = await this.pool.query(`SELECT user_id FROM auth_sessions WHERE token_hash = $1 AND expires_at > NOW()`, [tokenHash]);
      return res.rows[0]?.user_id || null;
    }
    const sess = this.memory.sessions.get(tokenHash);
    if (!sess || sess.expiresAt < new Date()) return null;
    return sess.userId;
  }

  async getFullProfileByUserId(userId) {
    if (this.usePostgres) {
      const profRes = await this.pool.query(
        `SELECT p.*, u.account_type, u.email FROM player_profiles p JOIN users u ON u.id = p.user_id WHERE p.user_id = $1`,
        [userId]
      );
      if (profRes.rowCount === 0) return null;
      const row = profRes.rows[0];
      const entRes = await this.pool.query(`SELECT outfit_id FROM outfit_entitlements WHERE user_id = $1 AND is_active = TRUE`, [userId]);
      const unlockedOutfits = entRes.rows.map(r => r.outfit_id);
      if (!unlockedOutfits.includes('none')) unlockedOutfits.unshift('none');

      return {
        userId: row.user_id,
        accountType: row.account_type,
        email: row.email || null,
        name: row.display_name,
        friendCode: row.friend_code,
        level: row.level,
        walletPoints: row.wallet_points,
        totalKOs: row.total_kos,
        selectedBreed: row.selected_breed,
        selectedOutfit: unlockedOutfits.includes(row.selected_outfit) ? row.selected_outfit : 'none',
        selectedHat: row.selected_hat,
        useCustomColors: row.use_custom_colors,
        customEyeLeft: row.custom_eye_left,
        customEyeRight: row.custom_eye_right,
        unlockedOutfits,
        friends: Array.isArray(row.friends) ? row.friends : [],
        serverRegion: row.server_region,
        currency: row.currency,
        sfxEnabled: row.sfx_enabled,
        musicEnabled: row.music_enabled,
        vibrationEnabled: row.vibration_enabled,
        sfxVolume: row.sfx_volume,
        musicVolume: row.music_volume,
        inActiveMatch: row.in_active_match,
        pendingDisconnectPenalty: row.pending_disconnect_penalty
      };
    }

    const p = this.memory.profiles.get(userId);
    const u = this.memory.users.get(userId);
    if (!p || !u) return null;
    const ents = Array.from(this.memory.entitlements.get(userId) || ['none']);
    return {
      ...p,
      accountType: u.accountType,
      email: u.email,
      unlockedOutfits: ents,
      selectedOutfit: ents.includes(p.selectedOutfit) ? p.selectedOutfit : 'none'
    };
  }

  async updateAppearanceAndSettings(userId, updates) {
    const clean = {};
    if (typeof updates.name === 'string') {
      const trimmed = updates.name.trim().replace(/[<>]/g, '').slice(0, 14);
      if (trimmed.length >= 1) clean.name = trimmed;
    }
    if (updates.selectedBreed && VALID_BREED_IDS.includes(updates.selectedBreed)) clean.selectedBreed = updates.selectedBreed;
    if (updates.selectedHat && VALID_HAT_IDS.includes(updates.selectedHat)) clean.selectedHat = updates.selectedHat;
    if (typeof updates.useCustomColors === 'boolean') clean.useCustomColors = updates.useCustomColors;
    if (typeof updates.customEyeLeft === 'string' && /^#[0-9a-fA-F]{6}$/.test(updates.customEyeLeft)) clean.customEyeLeft = updates.customEyeLeft;
    if (typeof updates.customEyeRight === 'string' && /^#[0-9a-fA-F]{6}$/.test(updates.customEyeRight)) clean.customEyeRight = updates.customEyeRight;
    if (updates.serverRegion && VALID_REGIONS.includes(updates.serverRegion)) clean.serverRegion = updates.serverRegion;
    if (updates.currency && VALID_CURRENCIES.includes(updates.currency)) clean.currency = updates.currency;
    if (Array.isArray(updates.friends)) {
      clean.friends = updates.friends.filter(f => typeof f === 'string').map(f => f.trim().slice(0, 20)).filter(Boolean).slice(0, 30);
    }
    if (typeof updates.sfxEnabled === 'boolean') clean.sfxEnabled = updates.sfxEnabled;
    if (typeof updates.musicEnabled === 'boolean') clean.musicEnabled = updates.musicEnabled;
    if (typeof updates.vibrationEnabled === 'boolean') clean.vibrationEnabled = updates.vibrationEnabled;
    if (typeof updates.sfxVolume === 'number') clean.sfxVolume = Math.max(0, Math.min(100, Math.round(updates.sfxVolume)));
    if (typeof updates.musicVolume === 'number') clean.musicVolume = Math.max(0, Math.min(100, Math.round(updates.musicVolume)));

    if (this.usePostgres) {
      const client = await this.pool.connect();
      try {
        await client.query('BEGIN');
        if (updates.selectedOutfit) {
          const entCheck = await client.query(
            `SELECT 1 FROM outfit_entitlements WHERE user_id = $1 AND outfit_id = $2 AND is_active = TRUE`,
            [userId, updates.selectedOutfit]
          );
          if (updates.selectedOutfit === 'none' || entCheck.rowCount > 0) {
            clean.selectedOutfit = updates.selectedOutfit;
          } else {
            throw new Error('OUTFIT_NOT_OWNED');
          }
        }
        const current = await this.getFullProfileByUserId(userId);
        const merged = { ...current, ...clean };
        await client.query(
          `UPDATE player_profiles
           SET display_name = $2, selected_breed = $3, selected_outfit = $4, selected_hat = $5,
               use_custom_colors = $6, custom_eye_left = $7, custom_eye_right = $8, server_region = $9,
               currency = $10, friends = $11::jsonb, sfx_enabled = $12, music_enabled = $13,
               vibration_enabled = $14, sfx_volume = $15, music_volume = $16, updated_at = NOW()
           WHERE user_id = $1`,
          [
            userId, merged.name, merged.selectedBreed, merged.selectedOutfit, merged.selectedHat,
            merged.useCustomColors, merged.customEyeLeft, merged.customEyeRight, merged.serverRegion,
            merged.currency, JSON.stringify(merged.friends), merged.sfxEnabled, merged.musicEnabled,
            merged.vibrationEnabled, merged.sfxVolume, merged.musicVolume
          ]
        );
        await client.query('COMMIT');
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      } finally {
        client.release();
      }
      return this.getFullProfileByUserId(userId);
    }

    return this._withMemoryLock(async () => {
      const p = this.memory.profiles.get(userId);
      const ents = this.memory.entitlements.get(userId) || new Set(['none']);
      if (!p) throw new Error('USER_NOT_FOUND');
      if (updates.selectedOutfit) {
        if (updates.selectedOutfit !== 'none' && !ents.has(updates.selectedOutfit)) {
          throw new Error('OUTFIT_NOT_OWNED');
        }
        clean.selectedOutfit = updates.selectedOutfit;
      }
      Object.assign(p, clean);
      return this.getFullProfileByUserId(userId);
    });
  }

  async unlockFreeOutfitWithPoints(userId, outfitId) {
    const catalogItem = AUTHORITATIVE_OUTFITS[outfitId];
    if (!catalogItem) throw new Error('INVALID_OUTFIT_ID');
    if (catalogItem.tier === 'Iconic' || catalogItem.tier === 'Mysterious') {
      throw new Error('PAID_OUTFIT_REQUIRES_VERIFIED_PAYMENT');
    }

    if (this.usePostgres) {
      const client = await this.pool.connect();
      try {
        await client.query('BEGIN');
        const profRes = await client.query(`SELECT level, wallet_points FROM player_profiles WHERE user_id = $1 FOR UPDATE`, [userId]);
        if (profRes.rowCount === 0) throw new Error('USER_NOT_FOUND');
        const { level, wallet_points } = profRes.rows[0];

        const existingRes = await client.query(
          `SELECT 1 FROM outfit_entitlements WHERE user_id = $1 AND outfit_id = $2 AND is_active = TRUE`,
          [userId, outfitId]
        );
        if (existingRes.rowCount > 0) {
          await client.query(`UPDATE player_profiles SET selected_outfit = $2, updated_at = NOW() WHERE user_id = $1`, [userId, outfitId]);
          await client.query('COMMIT');
          return this.getFullProfileByUserId(userId);
        }

        if (level < (catalogItem.reqLevel || 1)) throw new Error(`INSUFFICIENT_LEVEL_REQ_${catalogItem.reqLevel}`);
        if (wallet_points < (catalogItem.reqPoints || 0)) throw new Error(`INSUFFICIENT_POINTS_REQ_${catalogItem.reqPoints}`);

        const newBalance = wallet_points - (catalogItem.reqPoints || 0);
        await client.query(`UPDATE player_profiles SET wallet_points = $2, selected_outfit = $3, updated_at = NOW() WHERE user_id = $1`, [userId, newBalance, outfitId]);
        await client.query(
          `INSERT INTO outfit_entitlements (user_id, outfit_id, source) VALUES ($1, $2, 'points_unlock') ON CONFLICT (user_id, outfit_id) DO UPDATE SET is_active = TRUE`,
          [userId, outfitId]
        );
        await client.query(
          `INSERT INTO match_audit_logs (user_id, event_type, points_delta, metadata) VALUES ($1, 'unlock_free_outfit', $2, $3::jsonb)`,
          [userId, -(catalogItem.reqPoints || 0), JSON.stringify({ outfitId })]
        );
        await client.query('COMMIT');
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      } finally {
        client.release();
      }
      return this.getFullProfileByUserId(userId);
    }

    return this._withMemoryLock(async () => {
      const p = this.memory.profiles.get(userId);
      const ents = this.memory.entitlements.get(userId);
      if (!p || !ents) throw new Error('USER_NOT_FOUND');
      if (ents.has(outfitId)) {
        p.selectedOutfit = outfitId;
        return this.getFullProfileByUserId(userId);
      }
      if (p.level < (catalogItem.reqLevel || 1)) throw new Error(`INSUFFICIENT_LEVEL_REQ_${catalogItem.reqLevel}`);
      if (p.walletPoints < (catalogItem.reqPoints || 0)) throw new Error(`INSUFFICIENT_POINTS_REQ_${catalogItem.reqPoints}`);
      p.walletPoints -= (catalogItem.reqPoints || 0);
      ents.add(outfitId);
      p.selectedOutfit = outfitId;
      return this.getFullProfileByUserId(userId);
    });
  }

  async applyServerGameplayDelta(userId, { pointsDelta = 0, levelDelta = 0, kosDelta = 0, eventType = 'gameplay', metadata = {} }) {
    if (this.usePostgres) {
      const client = await this.pool.connect();
      try {
        await client.query('BEGIN');
        const res = await client.query(`SELECT level, wallet_points, total_kos FROM player_profiles WHERE user_id = $1 FOR UPDATE`, [userId]);
        if (res.rowCount === 0) {
          await client.query('ROLLBACK');
          return null;
        }
        const row = res.rows[0];
        const nextPoints = Math.max(0, row.wallet_points + Math.trunc(pointsDelta));
        const nextLevel = Math.max(1, Math.min(999, row.level + Math.trunc(levelDelta)));
        const nextKOs = Math.max(0, row.total_kos + Math.trunc(kosDelta));
        await client.query(`UPDATE player_profiles SET wallet_points = $2, level = $3, total_kos = $4, updated_at = NOW() WHERE user_id = $1`, [userId, nextPoints, nextLevel, nextKOs]);
        await client.query('COMMIT');
        return { level: nextLevel, walletPoints: nextPoints, totalKOs: nextKOs };
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      } finally {
        client.release();
      }
    }

    return this._withMemoryLock(async () => {
      const p = this.memory.profiles.get(userId);
      if (!p) return null;
      p.walletPoints = Math.max(0, p.walletPoints + Math.trunc(pointsDelta));
      p.level = Math.max(1, Math.min(999, p.level + Math.trunc(levelDelta)));
      p.totalKOs = Math.max(0, p.totalKOs + Math.trunc(kosDelta));
      return { level: p.level, walletPoints: p.walletPoints, totalKOs: p.totalKOs };
    });
  }

  async setMatchStatus(userId, { inActiveMatch, pendingDisconnectPenalty }) {
    if (this.usePostgres) {
      await this.pool.query(
        `UPDATE player_profiles SET in_active_match = COALESCE($2, in_active_match), pending_disconnect_penalty = COALESCE($3, pending_disconnect_penalty), updated_at = NOW() WHERE user_id = $1`,
        [userId, inActiveMatch ?? null, pendingDisconnectPenalty ?? null]
      );
      return;
    }
    return this._withMemoryLock(async () => {
      const p = this.memory.profiles.get(userId);
      if (!p) return;
      if (typeof inActiveMatch === 'boolean') p.inActiveMatch = inActiveMatch;
      if (typeof pendingDisconnectPenalty === 'boolean') p.pendingDisconnectPenalty = pendingDisconnectPenalty;
    });
  }
}

export const db = new DatabaseRepository();
