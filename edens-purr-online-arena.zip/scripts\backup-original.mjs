import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const SOURCE_CANDIDATES = [
  'eden_s_purr_final_regression_audited_3d_anime_cat_arena (2) - Copy.html',
  'index.original.html'
];

const BACKUP_DIR = path.resolve(process.cwd(), 'backups');
const BACKUP_FILE = path.join(BACKUP_DIR, 'eden_s_purr_original_backup.html');
const MANIFEST_FILE = path.join(BACKUP_DIR, 'backup_manifest.json');

function sha256(content) {
  return crypto.createHash('sha256').update(content).digest('hex');
}

function runBackup() {
  const sourceFile = SOURCE_CANDIDATES.map(f => path.resolve(process.cwd(), f)).find(p => fs.existsSync(p));
  if (!sourceFile) {
    if (fs.existsSync(BACKUP_FILE)) {
      console.log(`[BACKUP VERIFIED] Backup exists at ${BACKUP_FILE}`);
      return;
    }
    console.error('[BACKUP ERROR] Original HTML source file not found in working directory.');
    process.exit(1);
  }

  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }

  const rawBuffer = fs.readFileSync(sourceFile);
  const sourceHash = sha256(rawBuffer);

  if (fs.existsSync(BACKUP_FILE)) {
    const existingHash = sha256(fs.readFileSync(BACKUP_FILE));
    if (existingHash === sourceHash) {
      console.log(`[BACKUP VERIFIED] Untouched backup already exists at ${BACKUP_FILE}`);
      console.log(`[SHA-256] ${existingHash}`);
      return;
    }
  }

  fs.writeFileSync(BACKUP_FILE, rawBuffer, { flag: 'w' });
  try {
    fs.chmodSync(BACKUP_FILE, 0o444);
  } catch (_) {}

  const manifest = {
    originalFileName: path.basename(sourceFile),
    backupFilePath: 'backups/eden_s_purr_original_backup.html',
    byteLength: rawBuffer.byteLength,
    sha256: sourceHash,
    backedUpAt: new Date().toISOString()
  };

  fs.writeFileSync(MANIFEST_FILE, JSON.stringify(manifest, null, 2));
  console.log(`[BACKUP CREATED] Saved read-only copy to ${BACKUP_FILE}`);
  console.log(`[SHA-256] ${sourceHash} (${rawBuffer.byteLength} bytes)`);
}

runBackup();
