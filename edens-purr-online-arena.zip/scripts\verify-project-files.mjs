import fs from 'node:fs';
import path from 'node:path';

const REQUIRED_FILES = [
  'package.json',
  '.env.example',
  'render.yaml',
  'README.md',
  'backups/eden_s_purr_original_backup.html',
  'scripts/backup-original.mjs',
  'scripts/verify-project-files.mjs',
  'src/config/catalog.js',
  'src/db/database.js',
  'src/db/migrate.js',
  'src/db/migrations/001_initial_schema.sql',
  'src/middleware/security.js',
  'src/multiplayer/RoomManager.js',
  'src/services/paymentService.js',
  'src/server.js',
  'public/index.html',
  'public/js/multiplayer-bridge.js',
  'tests/security-and-multiplayer.test.mjs'
];

let missingCount = 0;

console.log("=== EDEN'S PURR — WINDOWS PROJECT FILE VERIFIER ===");

for (const relPath of REQUIRED_FILES) {
  const fullPath = path.resolve(process.cwd(), relPath);
  if (!fs.existsSync(fullPath)) {
    console.error(`[MISSING] ${relPath}`);
    missingCount++;
    continue;
  }
  const content = fs.readFileSync(fullPath, 'utf8').trim();
  if (content.length === 0) {
    console.error(`[EMPTY FILE] ${relPath}`);
    missingCount++;
    continue;
  }
  console.log(`[OK] ${relPath} (${content.length} chars)`);
}

if (missingCount > 0) {
  console.error(`\n[RESULT] ${missingCount} required file(s) are missing or empty.`);
  process.exit(1);
} else {
  console.log(`\n[RESULT] All ${REQUIRED_FILES.length} required project files exist and are non-empty!`);
}
