import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { io as createSocketClient } from 'socket.io-client';
import { createEdenServer } from '../src/server.js';

let serverInstance = null;
let ioInstance = null;
let roomManagerInstance = null;
let baseUrl = '';

async function requestWithCookie(path, { method = 'GET', body = null, cookie = '' } = {}) {
  const headers = {};
  if (cookie) headers['Cookie'] = cookie;
  if (body !== null) headers['Content-Type'] = 'application/json';

  const res = await fetch(`${baseUrl}${path}`, {
    method,
    headers,
    body: body !== null ? JSON.stringify(body) : undefined
  });

  const setCookieHeader = res.headers.get('set-cookie');
  const nextCookie = setCookieHeader ? setCookieHeader.split(';')[0] : cookie;
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data, cookie: nextCookie };
}

describe("Eden's Purr — Authoritative Security & Real-Time Multiplayer Suite", () => {
  before(async () => {
    const created = await createEdenServer();
    serverInstance = created.httpServer;
    ioInstance = created.io;
    roomManagerInstance = created.roomManager;
    await new Promise(resolve => serverInstance.listen(0, '127.0.0.1', resolve));
    const addr = serverInstance.address();
    baseUrl = `http://127.0.0.1:${addr.port}`;
  });

  after(async () => {
    if (roomManagerInstance) roomManagerInstance.stop();
    if (ioInstance) ioInstance.close();
    if (serverInstance && serverInstance.listening) {
      await new Promise(resolve => serverInstance.close(resolve));
    }
  });

  it('1. Serves the preserved 3D Arena HTML and health check cleanly', async () => {
    const healthRes = await fetch(`${baseUrl}/api/health`);
    assert.equal(healthRes.status, 200);
    const healthJson = await healthRes.json();
    assert.equal(healthJson.ok, true);

    const htmlRes = await fetch(`${baseUrl}/`);
    assert.equal(htmlRes.status, 200);
    const htmlText = await htmlRes.text();
    assert.ok(htmlText.includes("Eden's Purr — Global 3D Anime Cat Arena"));
    assert.ok(htmlText.includes('FluffyCatCharacter'));
  });

  it('2. Creates a persistent HttpOnly guest session and preserves identity across reloads', async () => {
    const first = await requestWithCookie('/api/session');
    assert.equal(first.status, 200);
    assert.ok(first.cookie.startsWith('edens_purr_sid='));
    assert.equal(first.data.profile.walletPoints, 350);
    assert.equal(first.data.profile.level, 1);

    const second = await requestWithCookie('/api/session', { cookie: first.cookie });
    assert.equal(second.status, 200);
    assert.equal(second.data.profile.userId, first.data.profile.userId);
  });

  it('3. Rejects forged walletPoints, forged levels, and unowned outfit equip attempts', async () => {
    const session = await requestWithCookie('/api/session');
    const cookie = session.cookie;

    const forgedAttempt = await requestWithCookie('/api/profile/appearance', {
      method: 'POST',
      cookie,
      body: { name: 'HackerCat', walletPoints: 999999, level: 99 }
    });
    assert.equal(forgedAttempt.status, 400);
    assert.equal(forgedAttempt.data.error, 'INVALID_APPEARANCE_PAYLOAD');

    const unownedEquip = await requestWithCookie('/api/profile/appearance', {
      method: 'POST',
      cookie,
      body: { selectedOutfit: 'rare_1' }
    });
    assert.equal(unownedEquip.status, 403);
    assert.equal(unownedEquip.data.error, 'OUTFIT_NOT_OWNED');
  });

  it('4. Allows valid Common outfit unlock with starter points and blocks unaffordable/high-level outfits', async () => {
    const session = await requestWithCookie('/api/session');
    const cookie = session.cookie;

    const validUnlock = await requestWithCookie('/api/profile/unlock-outfit', {
      method: 'POST',
      cookie,
      body: { outfitId: 'com_1' }
    });
    assert.equal(validUnlock.status, 200);
    assert.equal(validUnlock.data.profile.walletPoints, 250);
    assert.ok(validUnlock.data.profile.unlockedOutfits.includes('com_1'));
    assert.equal(validUnlock.data.profile.selectedOutfit, 'com_1');

    const invalidUnlock = await requestWithCookie('/api/profile/unlock-outfit', {
      method: 'POST',
      cookie,
      body: { outfitId: 'leg_1' }
    });
    assert.equal(invalidUnlock.status, 400);
    assert.match(invalidUnlock.data.error, /INSUFFICIENT_LEVEL/);
  });

  it('5. Blocks fake payment-complete requests and prevents unlocking Iconic or Mysterious outfits', async () => {
    const session = await requestWithCookie('/api/session');
    const cookie = session.cookie;

    const pointsBypass = await requestWithCookie('/api/profile/unlock-outfit', {
      method: 'POST',
      cookie,
      body: { outfitId: 'iconic_1' }
    });
    assert.equal(pointsBypass.status, 403);
    assert.equal(pointsBypass.data.error, 'PAID_OUTFIT_REQUIRES_VERIFIED_PAYMENT');

    const fakePaymentVerify = await requestWithCookie('/api/payments/verify-order', {
      method: 'POST',
      cookie,
      body: { outfitId: 'mysterious_omniverse' }
    });
    assert.equal(fakePaymentVerify.status, 403);
    assert.equal(fakePaymentVerify.data.verified, false);
  });

  it('6. Synchronizes two independent players in the same live Socket.IO room with movement & actions', async () => {
    const sessA = await requestWithCookie('/api/session');
    const sessB = await requestWithCookie('/api/session');

    await requestWithCookie('/api/profile/appearance', {
      method: 'POST',
      cookie: sessA.cookie,
      body: { name: 'AlphaCat', selectedBreed: 'callie' }
    });
    await requestWithCookie('/api/profile/appearance', {
      method: 'POST',
      cookie: sessB.cookie,
      body: { name: 'BetaCat', selectedBreed: 'bengal' }
    });

    const clientA = createSocketClient(baseUrl, { autoConnect: false, extraHeaders: { Cookie: sessA.cookie } });
    const clientB = createSocketClient(baseUrl, { autoConnect: false, extraHeaders: { Cookie: sessB.cookie } });

    try {
      const joinPromiseA = new Promise(resolve => clientA.once('room:joined', resolve));
      const joinPromiseB = new Promise(resolve => clientB.once('room:joined', resolve));
      clientA.connect();
      clientB.connect();

      const [joinedA, joinedB] = await Promise.all([joinPromiseA, joinPromiseB]);
      assert.equal(joinedA.roomId, 'global_arena_1');
      assert.equal(joinedB.roomId, 'global_arena_1');
      assert.notEqual(joinedA.playerId, joinedB.playerId);

      const actionPromise = new Promise(resolve => {
        clientB.on('player:action', (act) => {
          if (act.id === joinedA.playerId && act.type === 'meow') resolve(act);
        });
      });

      clientA.emit('player:move', { x: 12.5, y: 0, z: -8.25, rotY: 1.2, isLoafing: false });
      clientA.emit('player:action', { type: 'meow' });

      const receivedAction = await actionPromise;
      assert.equal(receivedAction.type, 'meow');

      const snapshot = await new Promise(resolve => {
        clientB.on('world:snapshot', (snap) => {
          const foundA = snap.players.find(p => p.id === joinedA.playerId);
          if (foundA && foundA.x === 12.5) resolve(snap);
        });
      });

      const playerAInSnap = snapshot.players.find(p => p.id === joinedA.playerId);
      const playerBInSnap = snapshot.players.find(p => p.id === joinedB.playerId);
      assert.equal(playerAInSnap.name, 'AlphaCat');
      assert.equal(playerBInSnap.name, 'BetaCat');
    } finally {
      clientA.disconnect();
      clientB.disconnect();
    }
  });
});
