import 'dotenv/config';
import { db } from './database.js';

async function main() {
  try {
    await db.init();
    console.log('[MIGRATE] Database schema is up to date.');
    process.exit(0);
  } catch (err) {
    console.error('[MIGRATE ERROR]', err);
    process.exit(1);
  }
}

main();
