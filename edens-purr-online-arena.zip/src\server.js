import 'dotenv/config';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { Server as SocketIOServer } from 'socket.io';
import { z } from 'zod';

import { db } from './db/database.js';
import {
  sessionMiddleware,
  authenticateSocketHandshake,
  apiLimiter,
  strictMutationLimiter
} from './middleware/security.js';
import { paymentService } from './services/paymentService.js';
import { RoomManager } from './multiplayer/RoomManager.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.resolve(__dirname, '..', 'public');

export async function createEdenServer() {
  await db.init();

  const app = express();
  const httpServer = http.createServer(app);

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'", "'unsafe-inline'", 'https://cdn.tailwindcss.com', 'https://cdnjs.cloudflare.com', 'https://unpkg.com'],
          scriptSrcAttr: ["'unsafe-inline'"],
          styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://unpkg.com'],
          fontSrc: ["'self'", 'https://fonts.gstatic.com', 'https://unpkg.com', 'data:'],
          imgSrc: ["'self'", 'data:', 'blob:'],
          connectSrc: ["'self'", 'ws:', 'wss:']
        }
      }
    })
  );

  const allowedOrigin = process.env.PUBLIC_ORIGIN || true;
  app.use(cors({ origin: allowedOrigin, credentials: true }));
  app.use(express.json({ limit: '32kb' }));
  app.use(sessionMiddleware);

  const io = new SocketIOServer(httpServer, {
    cors: { origin: allowedOrigin, credentials: true },
    maxHttpBufferSize: 16 * 1024
  });

  const roomManager = new RoomManager(io);

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, postgres: db.usePostgres, regions: roomManager.getRegionCounts() });
  });

  app.get('/api/session', apiLimiter, async (req, res) => {
    try {
      const profile = await db.getFullProfileByUserId(req.userId);
      if (profile.pendingDisconnectPenalty) {
        await db.setMatchStatus(req.userId, { pendingDisconnectPenalty: false });
      }
      res.json({
        profile,
        regions: roomManager.getRegionCounts(),
        paymentMode: paymentService.providerMode
      });
    } catch (err) {
      res.status(500).json({ error: 'FAILED_TO_LOAD_SESSION' });
    }
  });

  const appearanceSchema = z.object({
    name: z.string().min(1).max(14).optional(),
    selectedBreed: z.string().optional(),
    selectedOutfit: z.string().optional(),
    selectedHat: z.string().optional(),
    useCustomColors: z.boolean().optional(),
    customEyeLeft: z.string().optional(),
    customEyeRight: z.string().optional(),
    serverRegion: z.string().optional(),
    currency: z.string().optional(),
    friends: z.array(z.string()).optional(),
    sfxEnabled: z.boolean().optional(),
    musicEnabled: z.boolean().optional(),
    vibrationEnabled: z.boolean().optional(),
    sfxVolume: z.number().optional(),
    musicVolume: z.number().optional()
  }).strict();

  app.post('/api/profile/appearance', strictMutationLimiter, async (req, res) => {
    const parsed = appearanceSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'INVALID_APPEARANCE_PAYLOAD' });
    }
    try {
      const updated = await db.updateAppearanceAndSettings(req.userId, parsed.data);
      for (const room of roomManager.rooms.values()) {
        const rp = room.players.get(req.userId);
        if (rp) {
          rp.name = updated.name;
          rp.breed = updated.selectedBreed;
          rp.outfit = updated.selectedOutfit;
          rp.hat = updated.selectedHat;
          rp.useCustomColors = updated.useCustomColors;
          rp.customEyeLeft = updated.customEyeLeft;
          rp.customEyeRight = updated.customEyeRight;
          rp.friends = updated.friends;
        }
      }
      return res.json({ profile: updated });
    } catch (err) {
      if (err.message === 'OUTFIT_NOT_OWNED') {
        return res.status(403).json({ error: 'OUTFIT_NOT_OWNED' });
      }
      return res.status(400).json({ error: err.message || 'UPDATE_FAILED' });
    }
  });

  const unlockSchema = z.object({
    outfitId: z.string().min(1).max(64)
  }).strict();

  app.post('/api/profile/unlock-outfit', strictMutationLimiter, async (req, res) => {
    const parsed = unlockSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'INVALID_UNLOCK_PAYLOAD' });
    }
    try {
      const updated = await db.unlockFreeOutfitWithPoints(req.userId, parsed.data.outfitId);
      for (const room of roomManager.rooms.values()) {
        const rp = room.players.get(req.userId);
        if (rp) rp.outfit = updated.selectedOutfit;
      }
      return res.json({ profile: updated });
    } catch (err) {
      if (err.message === 'PAID_OUTFIT_REQUIRES_VERIFIED_PAYMENT') {
        return res.status(403).json({ error: err.message });
      }
      return res.status(400).json({ error: err.message || 'UNLOCK_FAILED' });
    }
  });

  app.get('/api/payments/checkout-info/:outfitId', apiLimiter, (req, res) => {
    try {
      const info = paymentService.getCheckoutStatusForOutfit(req.params.outfitId);
      return res.json(info);
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  });

  app.post('/api/payments/verify-order', strictMutationLimiter, async (req, res) => {
    const outfitId = typeof req.body?.outfitId === 'string' ? req.body.outfitId : '';
    const result = await paymentService.verifyPremiumPurchaseAttempt(req.userId, outfitId);
    if (!result.verified) {
      return res.status(403).json(result);
    }
    const profile = await db.getFullProfileByUserId(req.userId);
    return res.json({ ...result, profile });
  });

  app.use(express.static(PUBLIC_DIR));

  io.use(async (socket, next) => {
    try {
      const userId = await authenticateSocketHandshake(socket.handshake);
      if (!userId) return next(new Error('UNAUTHORIZED_SESSION'));
      socket.userId = userId;
      return next();
    } catch (err) {
      return next(new Error('SOCKET_AUTH_ERROR'));
    }
  });

  io.on('connection', async (socket) => {
    const userId = socket.userId;
    const profile = await db.getFullProfileByUserId(userId);
    if (!profile) {
      socket.disconnect(true);
      return;
    }

    let currentRoom = roomManager.findAvailableRoom(profile.serverRegion, userId);
    socket.join(currentRoom.roomId);
    currentRoom.addOrReconnectPlayer(userId, socket.id, profile);

    socket.emit('room:joined', {
      roomId: currentRoom.roomId,
      region: currentRoom.region,
      playerId: userId,
      profile,
      collectibles: Array.from(currentRoom.collectibles.values())
    });

    currentRoom.broadcastSnapshot();

    socket.on('player:move', (payload) => {
      if (!payload || typeof payload !== 'object') return;
      currentRoom.handlePlayerMove(userId, payload);
    });

    socket.on('player:action', (action) => {
      if (!action || typeof action !== 'object') return;
      currentRoom.handlePlayerAction(userId, action);
    });

    socket.on('match:start', async () => {
      await currentRoom.startMatchForPlayer(userId);
    });

    socket.on('match:quit_midgame', async () => {
      const p = currentRoom.players.get(userId);
      if (p && p.inMatch) {
        p.inMatch = false;
        const updated = await db.applyServerGameplayDelta(userId, {
          levelDelta: -1,
          eventType: 'midgame_quit_penalty'
        });
        await db.setMatchStatus(userId, { inActiveMatch: false, pendingDisconnectPenalty: false });
        if (updated) p.level = updated.level;
      }
    });

    socket.on('match:finish_early', async () => {
      const p = currentRoom.players.get(userId);
      if (p && p.inMatch && currentRoom.areAllMissionsDone(p)) {
        await currentRoom.advanceRoundForPlayer(p, true);
      }
    });

    socket.on('room:switch_region', async (payload) => {
      const nextRegion = payload?.region;
      if (!nextRegion || typeof nextRegion !== 'string') return;
      const updatedProfile = await db.updateAppearanceAndSettings(userId, { serverRegion: nextRegion });
      socket.leave(currentRoom.roomId);
      currentRoom.players.delete(userId);
      currentRoom = roomManager.findAvailableRoom(updatedProfile.serverRegion, userId);
      socket.join(currentRoom.roomId);
      currentRoom.addOrReconnectPlayer(userId, socket.id, updatedProfile);
      socket.emit('room:joined', {
        roomId: currentRoom.roomId,
        region: currentRoom.region,
        playerId: userId,
        profile: updatedProfile,
        collectibles: Array.from(currentRoom.collectibles.values())
      });
    });

    socket.on('disconnect', () => {
      roomManager.handleDisconnect(userId, socket.id);
    });
  });

  return { app, httpServer, io, roomManager };
}

const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  const port = Number(process.env.PORT) || 3000;
  createEdenServer()
    .then(({ httpServer }) => {
      httpServer.listen(port, () => {
        console.log(`[EDEN'S PURR SERVER] Live on http://localhost:${port}`);
      });
    })
    .catch((err) => {
      console.error('[SERVER STARTUP ERROR]', err);
      process.exit(1);
    });
}
