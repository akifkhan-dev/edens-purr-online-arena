CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY,
    account_type VARCHAR(16) NOT NULL DEFAULT 'guest' CHECK (account_type IN ('guest', 'registered')),
    email VARCHAR(255) UNIQUE,
    password_hash TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS auth_sessions (
    token_hash VARCHAR(64) PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_agent TEXT,
    ip_address VARCHAR(64),
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_auth_sessions_user_id ON auth_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_auth_sessions_expires_at ON auth_sessions(expires_at);

CREATE TABLE IF NOT EXISTS player_profiles (
    user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    display_name VARCHAR(16) NOT NULL DEFAULT 'SmokeyPurr',
    friend_code VARCHAR(16) NOT NULL UNIQUE,
    level INTEGER NOT NULL DEFAULT 1 CHECK (level >= 1 AND level <= 999),
    wallet_points INTEGER NOT NULL DEFAULT 350 CHECK (wallet_points >= 0),
    total_kos INTEGER NOT NULL DEFAULT 0 CHECK (total_kos >= 0),
    selected_breed VARCHAR(32) NOT NULL DEFAULT 'smokey',
    selected_outfit VARCHAR(64) NOT NULL DEFAULT 'none',
    selected_hat VARCHAR(32) NOT NULL DEFAULT 'crown',
    use_custom_colors BOOLEAN NOT NULL DEFAULT FALSE,
    custom_eye_left VARCHAR(16) NOT NULL DEFAULT '#ffbf36',
    custom_eye_right VARCHAR(16) NOT NULL DEFAULT '#4cd98c',
    server_region VARCHAR(16) NOT NULL DEFAULT 'global',
    currency VARCHAR(8) NOT NULL DEFAULT 'INR',
    friends JSONB NOT NULL DEFAULT '[]'::jsonb,
    sfx_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    music_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    vibration_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    sfx_volume INTEGER NOT NULL DEFAULT 85 CHECK (sfx_volume >= 0 AND sfx_volume <= 100),
    music_volume INTEGER NOT NULL DEFAULT 70 CHECK (music_volume >= 0 AND music_volume <= 100),
    in_active_match BOOLEAN NOT NULL DEFAULT FALSE,
    pending_disconnect_penalty BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS outfit_entitlements (
    id BIGSERIAL PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    outfit_id VARCHAR(64) NOT NULL,
    source VARCHAR(24) NOT NULL CHECK (source IN ('starter', 'points_unlock', 'verified_payment')),
    transaction_id VARCHAR(128),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    granted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    revoked_at TIMESTAMPTZ,
    UNIQUE (user_id, outfit_id)
);
CREATE INDEX IF NOT EXISTS idx_outfit_entitlements_user ON outfit_entitlements(user_id) WHERE is_active = TRUE;

CREATE TABLE IF NOT EXISTS payment_orders (
    order_id VARCHAR(32) PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    outfit_id VARCHAR(64) NOT NULL,
    tier VARCHAR(24) NOT NULL CHECK (tier IN ('Iconic', 'Mysterious')),
    expected_amount_inr INTEGER NOT NULL CHECK (expected_amount_inr > 0),
    expected_amount_usd NUMERIC(10, 2) NOT NULL CHECK (expected_amount_usd > 0),
    status VARCHAR(24) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'COMPLETED', 'CANCELLED', 'EXPIRED', 'REFUNDED', 'DISPUTED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS payment_transactions (
    id BIGSERIAL PRIMARY KEY,
    provider VARCHAR(32) NOT NULL,
    provider_tx_id VARCHAR(128) NOT NULL,
    order_id VARCHAR(32) REFERENCES payment_orders(order_id),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    outfit_id VARCHAR(64) NOT NULL,
    amount NUMERIC(10, 2) NOT NULL,
    currency VARCHAR(12) NOT NULL,
    status VARCHAR(24) NOT NULL CHECK (status IN ('SUCCEEDED', 'PENDING', 'FAILED', 'REFUNDED', 'DISPUTED')),
    raw_event_hash VARCHAR(64) NOT NULL,
    verified_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (provider, provider_tx_id)
);

CREATE TABLE IF NOT EXISTS match_audit_logs (
    id BIGSERIAL PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    event_type VARCHAR(48) NOT NULL,
    points_delta INTEGER NOT NULL DEFAULT 0,
    level_delta INTEGER NOT NULL DEFAULT 0,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_match_audit_logs_user ON match_audit_logs(user_id);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE auth_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE player_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE outfit_entitlements ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE match_audit_logs ENABLE ROW LEVEL SECURITY;
