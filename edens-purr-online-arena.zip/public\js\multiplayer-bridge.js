export class EdensPurrMultiplayerBridge {
  constructor(hooks) {
    this.hooks = hooks;
    this.socket = null;
    this.connected = false;
    this.roomId = null;
    this.playerId = null;
    this.moveSendInterval = null;
  }

  async init() {
    await this.syncSessionFromServer();
    this.connectSocket();
    this.startMovementSender();
  }

  async syncSessionFromServer() {
    try {
      const res = await fetch('/api/session', { credentials: 'include' });
      if (!res.ok) return;
      const data = await res.json();
      if (data.profile) {
        this.hooks.applyServerProfile(data.profile, data.regions);
      }
    } catch (err) {
      console.warn('[EdenBridge] Offline or local file mode:', err);
    }
  }

  async saveAppearanceToServer(partialProfile) {
    try {
      const res = await fetch('/api/profile/appearance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(partialProfile)
      });
      if (!res.ok) return null;
      const data = await res.json();
      if (data.profile) {
        this.hooks.applyServerProfile(data.profile);
      }
      return data.profile;
    } catch (err) {
      return null;
    }
  }

  async unlockFreeOutfitOnServer(outfitId) {
    const res = await fetch('/api/profile/unlock-outfit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ outfitId })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'UNLOCK_REJECTED');
    }
    if (data.profile) {
      this.hooks.applyServerProfile(data.profile);
    }
    return data.profile;
  }

  async verifyPremiumPaymentOnServer(outfitId) {
    const res = await fetch('/api/payments/verify-order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ outfitId })
    });
    const data = await res.json();
    return { ok: res.ok, ...data };
  }

  connectSocket() {
    if (typeof window.io !== 'function') return;

    this.socket = window.io({
      withCredentials: true,
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: Infinity
    });

    this.socket.on('connect', () => {
      this.connected = true;
      this.hooks.onConnectionStatusChange?.(true);
    });

    this.socket.on('disconnect', () => {
      this.connected = false;
      this.hooks.onConnectionStatusChange?.(false);
    });

    this.socket.on('room:joined', (payload) => {
      this.roomId = payload.roomId;
      this.playerId = payload.playerId;
      if (payload.profile) {
        this.hooks.applyServerProfile(payload.profile);
      }
      if (Array.isArray(payload.collectibles)) {
        this.hooks.syncServerCollectibles?.(payload.collectibles);
      }
    });

    this.socket.on('world:snapshot', (snapshot) => {
      this.hooks.onWorldSnapshot?.(snapshot, this.playerId);
    });

    this.socket.on('collectible:respawn', (colData) => {
      this.hooks.onCollectibleRespawn?.(colData);
    });

    this.socket.on('player:action', (act) => {
      if (act.id === this.playerId) return;
      this.hooks.onRemotePlayerAction?.(act);
    });

    this.socket.on('player:left', ({ id }) => {
      this.hooks.onRemotePlayerLeft?.(id);
    });

    this.socket.on('match:reward', (reward) => {
      this.hooks.onServerMatchReward?.(reward);
    });
  }

  startMovementSender() {
    if (this.moveSendInterval) clearInterval(this.moveSendInterval);
    this.moveSendInterval = setInterval(() => {
      if (!this.connected || !this.socket) return;
      const state = this.hooks.getLocalMovementPayload?.();
      if (state) {
        this.socket.emit('player:move', state);
      }
    }, 66);
  }

  sendAction(type, extra = {}) {
    if (!this.connected || !this.socket) return;
    this.socket.emit('player:action', { type, ...extra });
  }

  notifyMatchStart() {
    if (this.connected && this.socket) this.socket.emit('match:start');
  }

  notifyMidgameQuit() {
    if (this.connected && this.socket) this.socket.emit('match:quit_midgame');
  }

  notifyEarlyFinish() {
    if (this.connected && this.socket) this.socket.emit('match:finish_early');
  }

  switchRegion(regionId) {
    if (this.connected && this.socket) {
      this.socket.emit('room:switch_region', { region: regionId });
    }
  }
}
