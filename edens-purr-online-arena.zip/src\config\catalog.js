export const PHYSICS_CONSTANTS = Object.freeze({
  ISLAND_RADIUS: 95,
  BOUNDARY_LIMIT: 92.8,
  BASE_MOVE_SPEED: 13.5,
  SUPER_MOVE_SPEED: 19.5,
  POUNCE_DASH_SPEED: 27,
  SUPER_POUNCE_DASH_SPEED: 42,
  MAX_ALLOWED_SPEED_UNITS_PER_SEC: 48,
  BOOP_HIT_RADIUS: 3.3,
  COLLECTIBLE_PICKUP_RADIUS: 3.6,
  ROUND_DURATIONS_SEC: [300, 270, 240],
  IDLE_FREEZE_THRESHOLD_SEC: 10.0,
  IDLE_FREEZE_DURATION_SEC: 10.0,
  IDLE_FREEZE_POINT_PENALTY: 150,
  MAX_FREEZES_PER_ROUND: 3,
  MAX_BOOPS_RECEIVED_PER_ROUND: 3,
  KO_BOOPS_IN_WINDOW: 5,
  KO_WINDOW_MS: 15000,
  KO_STUN_DURATION_SEC: 15.0,
  POWER_NAP_HOPS_REQUIRED: 6,
  POWER_NAP_DURATION_SEC: 2.0
});

export const VALID_BREED_IDS = Object.freeze([
  'smokey', 'callie', 'scottish', 'siamese', 'persian', 'bengal', 'munchkin', 'mainecoon'
]);

export const VALID_HAT_IDS = Object.freeze([
  'none', 'crown', 'sakura', 'frog', 'halo', 'sprout', 'tiara', 'beret', 'nightcap', 'kitsune', 'unicorn', 'chef'
]);

export const VALID_REGIONS = Object.freeze(['global', 'asia', 'na', 'eu', 'sa']);
export const VALID_CURRENCIES = Object.freeze(['INR', 'USD', 'EUR', 'GBP', 'JPY', 'AED']);

export const AUTHORITATIVE_OUTFITS = Object.freeze({
  none: { id: 'none', name: 'Natural Fluffy Coat', tier: 'Starter', reqLevel: 1, reqPoints: 0 },
  com_1:  { id: 'com_1',  name: 'Ruby Sailor Uniform',          tier: 'Common', reqLevel: 1, reqPoints: 100 },
  com_2:  { id: 'com_2',  name: 'Strawberry Knit Cardigan',     tier: 'Common', reqLevel: 1, reqPoints: 125 },
  com_3:  { id: 'com_3',  name: 'Bumblebee Striped Hoodie',     tier: 'Common', reqLevel: 1, reqPoints: 150 },
  com_4:  { id: 'com_4',  name: 'Mint Polka-Dot Pinafore',      tier: 'Common', reqLevel: 1, reqPoints: 175 },
  com_5:  { id: 'com_5',  name: 'Cozy Lavender Pajama Set',     tier: 'Common', reqLevel: 1, reqPoints: 200 },
  com_6:  { id: 'com_6',  name: 'Sunny Sunflower Overalls',     tier: 'Common', reqLevel: 1, reqPoints: 225 },
  com_7:  { id: 'com_7',  name: 'Peach Gingham Maid Apron',     tier: 'Common', reqLevel: 1, reqPoints: 250 },
  com_8:  { id: 'com_8',  name: 'Sky Blue Raincoat & Bow',      tier: 'Common', reqLevel: 1, reqPoints: 280 },
  com_9:  { id: 'com_9',  name: 'Cherry Blossom Haori Jacket',  tier: 'Common', reqLevel: 1, reqPoints: 310 },
  com_10: { id: 'com_10', name: 'Marshmallow Puffer Vest',      tier: 'Common', reqLevel: 1, reqPoints: 350 },
  rare_1:  { id: 'rare_1',  name: 'Royal Crimson Velvet Cape',     tier: 'Rare', reqLevel: 6, reqPoints: 700 },
  rare_2:  { id: 'rare_2',  name: 'Emerald Forest Ranger Cloak',   tier: 'Rare', reqLevel: 6, reqPoints: 780 },
  rare_3:  { id: 'rare_3',  name: 'Sapphire Starlight Kimono',     tier: 'Rare', reqLevel: 6, reqPoints: 850 },
  rare_4:  { id: 'rare_4',  name: 'Amethyst Witch Academy Robe',   tier: 'Rare', reqLevel: 6, reqPoints: 920 },
  rare_5:  { id: 'rare_5',  name: 'Golden Pharaoh Collar & Linen', tier: 'Rare', reqLevel: 6, reqPoints: 1000 },
  rare_6:  { id: 'rare_6',  name: 'Arctic Fox Fur-Trimmed Parka',  tier: 'Rare', reqLevel: 6, reqPoints: 1080 },
  rare_7:  { id: 'rare_7',  name: 'Steampunk Brass Gear Vest',     tier: 'Rare', reqLevel: 6, reqPoints: 1160 },
  rare_8:  { id: 'rare_8',  name: 'Coral Mermaid Scale Gown',      tier: 'Rare', reqLevel: 6, reqPoints: 1240 },
  rare_9:  { id: 'rare_9',  name: 'Jade Dragon Martial Tunic',     tier: 'Rare', reqLevel: 6, reqPoints: 1320 },
  rare_10: { id: 'rare_10', name: 'Rose-Gold Ballerina Tutu',      tier: 'Rare', reqLevel: 6, reqPoints: 1400 },
  leg_1:  { id: 'leg_1',  name: 'Celestial Valkyrie Golden Armor', tier: 'Legendary', reqLevel: 10, reqPoints: 2200 },
  leg_2:  { id: 'leg_2',  name: 'Cyber-Neko Neon Holo-Suit',       tier: 'Legendary', reqLevel: 10, reqPoints: 2400 },
  leg_3:  { id: 'leg_3',  name: 'Astral Nine-Tail Kitsune Regalia',tier: 'Legendary', reqLevel: 10, reqPoints: 2600 },
  leg_4:  { id: 'leg_4',  name: 'Solar Phoenix Flame Mantle',      tier: 'Legendary', reqLevel: 10, reqPoints: 2800 },
  leg_5:  { id: 'leg_5',  name: 'Lunar Eclipse Shadow Plate',      tier: 'Legendary', reqLevel: 10, reqPoints: 3000 },
  leg_6:  { id: 'leg_6',  name: 'Crystal Paladin Winged Cuirass',  tier: 'Legendary', reqLevel: 10, reqPoints: 3200 },
  leg_7:  { id: 'leg_7',  name: 'Nebula Archmage Floating Runes',  tier: 'Legendary', reqLevel: 10, reqPoints: 3400 },
  leg_8:  { id: 'leg_8',  name: 'Void Walker Chrono Coat',         tier: 'Legendary', reqLevel: 10, reqPoints: 3600 },
  leg_9:  { id: 'leg_9',  name: 'Sakura Empress Imperial Robes',   tier: 'Legendary', reqLevel: 10, reqPoints: 3800 },
  leg_10: { id: 'leg_10', name: 'Thunder Raijin Storm Drums',      tier: 'Legendary', reqLevel: 10, reqPoints: 4000 },
  iconic_1:  { id: 'iconic_1',  name: '✨ Seraphim Six-Winged Empress',    tier: 'Iconic', priceINR: 100, priceUSD: 1.06 },
  iconic_2:  { id: 'iconic_2',  name: '🐉 Sakura Dragon Sovereign',        tier: 'Iconic', priceINR: 100, priceUSD: 1.06 },
  iconic_3:  { id: 'iconic_3',  name: '🌌 Cosmic Supernova Monarch',       tier: 'Iconic', priceINR: 100, priceUSD: 1.06 },
  iconic_4:  { id: 'iconic_4',  name: '🔥 Solar Phoenix Immortal',         tier: 'Iconic', priceINR: 100, priceUSD: 1.06 },
  iconic_5:  { id: 'iconic_5',  name: '👑 Royal Maharaja Golden Howdah',   tier: 'Iconic', priceINR: 100, priceUSD: 1.06 },
  iconic_6:  { id: 'iconic_6',  name: '🤖 Neon Cyber-Shogun Mecha',        tier: 'Iconic', priceINR: 100, priceUSD: 1.06 },
  iconic_7:  { id: 'iconic_7',  name: '❄️ Aurora Borealis Ice Palace',     tier: 'Iconic', priceINR: 100, priceUSD: 1.06 },
  iconic_8:  { id: 'iconic_8',  name: '☀️ Sun-God Ra Solar Barque',        tier: 'Iconic', priceINR: 100, priceUSD: 1.06 },
  iconic_9:  { id: 'iconic_9',  name: '🧜‍♀️ Abyssal Siren Kraken Throne',   tier: 'Iconic', priceINR: 100, priceUSD: 1.06 },
  iconic_10: { id: 'iconic_10', name: '🌈 Bifrost Prism Pegasus Valkyrie', tier: 'Iconic', priceINR: 100, priceUSD: 1.06 },
  mysterious_omniverse: {
    id: 'mysterious_omniverse',
    name: '✨ THE ETERNAL OMEGA CELESTIAL DEITY ✨',
    tier: 'Mysterious',
    priceINR: 200,
    priceUSD: 2.12
  }
});

export const BOT_PROFILES = Object.freeze([
  { id: 'bot_0', name: 'Callie 🌸',      breed: 'callie',    outfit: 'com_1',   hat: 'sakura' },
  { id: 'bot_1', name: 'MochiBun 🍓',    breed: 'scottish',  outfit: 'com_2',   hat: 'beret' },
  { id: 'bot_2', name: 'ChaiRoyale 👑',  breed: 'siamese',   outfit: 'rare_1',  hat: 'crown' },
  { id: 'bot_3', name: 'CloudyFluff ☁️', breed: 'persian',   outfit: 'rare_3',  hat: 'halo' },
  { id: 'bot_4', name: 'RajaTiger 🐯',   breed: 'bengal',    outfit: 'com_3',   hat: 'frog' },
  { id: 'bot_5', name: 'Biscuit 🥞',     breed: 'munchkin',  outfit: 'rare_10', hat: 'sprout' },
  { id: 'bot_6', name: 'NebulaLion 🌌',  breed: 'mainecoon', outfit: 'leg_3',   hat: 'unicorn' }
]);
