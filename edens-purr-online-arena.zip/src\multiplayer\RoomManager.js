import {
  PHYSICS_CONSTANTS,
  BOT_PROFILES,
  VALID_REGIONS
} from '../config/catalog.js';
import { db } from '../db/database.js';

class GameRoom {
  constructor(roomId, region, io, maxPlayers = 16) {
    this.roomId = roomId;
    this.region = region;
    this.io = io;
    this.maxPlayers = maxPlayers;
    this.players = new Map();
    this.bots = new Map();
    this.collectibles = new Map();
    this.initCollectibles();
    this.initBots();
  }

  initCollectibles() {
    this.collectibles.clear();
    for (let i = 0; i < 55; i++) {
      const id = `col_${i}`;
      const type = i % 4 === 0 ? 'star' : 'yarn';
      const value = type === 'star' ? 35 : 20;
      const pos = this.randomIslandPosition();
      this.collectibles.set(id, { id, type, value, x: pos.x, y: 0.8, z: pos.z });
    }
  }

  initBots() {
    this.bots.clear();
    BOT_PROFILES.forEach((bp, idx) => {
      const angle = (idx / BOT_PROFILES.length) * Math.PI * 2;
      const x = Math.cos(angle) * 28;
      const z = Math.sin(angle) * 28;
      this.bots.set(bp.id, {
        id: bp.id, name: bp.name, breed: bp.breed, outfit: bp.outfit, hat: bp.hat,
        isBot: true, x, y: 0, z, vx: 0, vy: 0, vz: 0, rotY: 0,
        score: Math.floor(15 + Math.random() * 35),
        isPouncing: false, pounceTimer: 0, napTimer: 0, unconsciousTimer: 0, freezeTimer: 0,
        boopTimestamps: [], targetX: x, targetZ: z, aiTimer: 0
      });
    });
  }

  randomIslandPosition() {
    const angle = Math.random() * Math.PI * 2;
    const r = 10 + Math.random() * (PHYSICS_CONSTANTS.ISLAND_RADIUS - 16);
    return {
      x: Number((Math.cos(angle) * r).toFixed(2)),
      z: Number((Math.sin(angle) * r).toFixed(2))
    };
  }

  hasCapacityFor(userId) {
    if (this.players.has(userId)) return true;
    return this.players.size < this.maxPlayers;
  }

  addOrReconnectPlayer(userId, socketId, profile) {
    const existing = this.players.get(userId);
    if (existing) {
      if (existing.disconnectTimer) {
        clearTimeout(existing.disconnectTimer);
        existing.disconnectTimer = null;
      }
      existing.socketId = socketId;
      existing.connected = true;
      existing.name = profile.name;
      existing.breed = profile.selectedBreed;
      existing.outfit = profile.selectedOutfit;
      existing.hat = profile.selectedHat;
      existing.useCustomColors = profile.useCustomColors;
      existing.customEyeLeft = profile.customEyeLeft;
      existing.customEyeRight = profile.customEyeRight;
      existing.level = profile.level;
      existing.friends = profile.friends || [];
      return existing;
    }

    const angle = Math.random() * Math.PI * 2;
    const dist = 6 + Math.random() * 10;
    const state = {
      id: userId, socketId, connected: true, disconnectTimer: null,
      name: profile.name, breed: profile.selectedBreed, outfit: profile.selectedOutfit, hat: profile.selectedHat,
      useCustomColors: profile.useCustomColors, customEyeLeft: profile.customEyeLeft, customEyeRight: profile.customEyeRight,
      level: profile.level, friends: profile.friends || [],
      inMatch: false, currentRound: 1, roundTimeLeft: PHYSICS_CONSTANTS.ROUND_DURATIONS_SEC[0],
      x: Number((Math.cos(angle) * dist).toFixed(2)), y: 0, z: Number((Math.sin(angle) * dist).toFixed(2)),
      vx: 0, vy: 0, vz: 0, rotY: 0, score: 0,
      isPouncing: false, pounceTimer: 0, isLoafing: false, napTimer: 0, unconsciousTimer: 0, freezeTimer: 0,
      superpowerTimer: 0, superpowerUsedThisRound: false, hopCount: 0, hopResetTimer: 0,
      boopTimestamps: [], roundBoopsReceived: 0, roundFreezeCount: 0, idleSeconds: 0,
      lastMovedX: 0, lastMovedZ: 0, missions: this.createMissionsForRound(1),
      lastMovePacketAt: Date.now(), movePacketCountWindow: 0, moveWindowStart: Date.now()
    };
    this.players.set(userId, state);
    return state;
  }

  createMissionsForRound(roundNum) {
    return {
      yarn: { current: 0, target: 8 + roundNum * 3, done: false },
      boop: { current: 0, target: 2 + roundNum, done: false },
      social: { current: 0, target: 4, done: false }
    };
  }

  progressMission(player, key, amount = 1) {
    const m = player.missions?.[key];
    if (!m || m.done) return false;
    m.current = Math.min(m.target, m.current + amount);
    if (m.current >= m.target) {
      m.done = true;
      return true;
    }
    return false;
  }

  areAllMissionsDone(player) {
    if (!player.missions) return false;
    return Object.values(player.missions).every(m => m.done);
  }

  async startMatchForPlayer(userId) {
    const p = this.players.get(userId);
    if (!p) return null;
    p.inMatch = true;
    p.currentRound = 1;
    p.roundTimeLeft = PHYSICS_CONSTANTS.ROUND_DURATIONS_SEC[0];
    p.score = 0;
    p.roundBoopsReceived = 0;
    p.roundFreezeCount = 0;
    p.idleSeconds = 0;
    p.freezeTimer = 0;
    p.unconsciousTimer = 0;
    p.napTimer = 0;
    p.superpowerTimer = 0;
    p.superpowerUsedThisRound = false;
    p.missions = this.createMissionsForRound(1);
    p.lastMovedX = p.x;
    p.lastMovedZ = p.z;
    await db.setMatchStatus(userId, { inActiveMatch: true, pendingDisconnectPenalty: false });
    return p;
  }

  handlePlayerMove(userId, payload) {
    const p = this.players.get(userId);
    if (!p || !p.connected) return;

    const now = Date.now();
    if (now - p.moveWindowStart > 1000) {
      p.moveWindowStart = now;
      p.movePacketCountWindow = 0;
    }
    p.movePacketCountWindow++;
    if (p.movePacketCountWindow > 38) return;
    if (p.freezeTimer > 0 || p.unconsciousTimer > 0) return;

    const dt = Math.max(0.016, Math.min(0.5, (now - p.lastMovePacketAt) / 1000));
    p.lastMovePacketAt = now;

    const nextX = Number(payload.x);
    const nextY = Number(payload.y);
    const nextZ = Number(payload.z);
    const nextRotY = Number(payload.rotY);
    if (!Number.isFinite(nextX) || !Number.isFinite(nextY) || !Number.isFinite(nextZ) || !Number.isFinite(nextRotY)) return;

    const radialDist = Math.hypot(nextX, nextZ);
    let clampedX = nextX;
    let clampedZ = nextZ;
    if (radialDist > PHYSICS_CONSTANTS.ISLAND_RADIUS - 2.0) {
      const a = Math.atan2(nextZ, nextX);
      clampedX = Math.cos(a) * (PHYSICS_CONSTANTS.ISLAND_RADIUS - 2.2);
      clampedZ = Math.sin(a) * (PHYSICS_CONSTANTS.ISLAND_RADIUS - 2.2);
    }

    const stepDist = Math.hypot(clampedX - p.x, clampedZ - p.z);
    const maxStep = PHYSICS_CONSTANTS.MAX_ALLOWED_SPEED_UNITS_PER_SEC * dt + 3.5;
    if (stepDist > maxStep) {
      const dirA = Math.atan2(clampedZ - p.z, clampedX - p.x);
      clampedX = p.x + Math.cos(dirA) * maxStep;
      clampedZ = p.z + Math.sin(dirA) * maxStep;
    }

    p.vx = (clampedX - p.x) / dt;
    p.vz = (clampedZ - p.z) / dt;
    p.x = Number(clampedX.toFixed(2));
    p.y = Number(Math.max(0, Math.min(28, nextY)).toFixed(2));
    p.z = Number(clampedZ.toFixed(2));
    p.rotY = Number(nextRotY.toFixed(3));
    p.isLoafing = Boolean(payload.isLoafing);
  }

  handlePlayerAction(userId, action) {
    const p = this.players.get(userId);
    if (!p || !p.connected || p.freezeTimer > 0 || p.unconsciousTimer > 0) return;

    const type = action?.type;
    if (type === 'hop') {
      p.hopCount++;
      p.hopResetTimer = 3.2;
      this.progressMission(p, 'social', 1);
      if (p.hopCount >= PHYSICS_CONSTANTS.POWER_NAP_HOPS_REQUIRED) {
        p.hopCount = 0;
        p.napTimer = PHYSICS_CONSTANTS.POWER_NAP_DURATION_SEC;
      }
      this.io.to(this.roomId).emit('player:action', { id: p.id, type: 'hop', napTimer: p.napTimer });
    } else if (type === 'pounce') {
      if (p.napTimer > 0) return;
      p.isPouncing = true;
      p.pounceTimer = 0.45;
      this.io.to(this.roomId).emit('player:action', { id: p.id, type: 'pounce' });
    } else if (type === 'purr' || type === 'meow' || type === 'emote') {
      this.progressMission(p, 'social', 1);
      this.io.to(this.roomId).emit('player:action', { id: p.id, type, breed: p.breed, emoteIndex: action.emoteIndex });
    } else if (type === 'superpower') {
      if (p.superpowerUsedThisRound || p.superpowerTimer > 0) return;
      if (!this.isTopScorer(p.id)) return;
      p.superpowerUsedThisRound = true;
      p.superpowerTimer = 10.0;
      this.io.to(this.roomId).emit('player:action', { id: p.id, type: 'superpower' });
    }
  }

  isTopScorer(userId) {
    const all = [...this.players.values(), ...this.bots.values()];
    all.sort((a, b) => b.score - a.score);
    return all[0]?.id === userId && all[0].score > 0;
  }

  async tick(dt) {
    for (const p of this.players.values()) {
      if (!p.connected) continue;
      if (p.pounceTimer > 0) {
        p.pounceTimer = Math.max(0, p.pounceTimer - dt);
        if (p.pounceTimer <= 0) p.isPouncing = false;
      }
      if (p.napTimer > 0) p.napTimer = Math.max(0, p.napTimer - dt);
      if (p.unconsciousTimer > 0) p.unconsciousTimer = Math.max(0, p.unconsciousTimer - dt);
      if (p.freezeTimer > 0) p.freezeTimer = Math.max(0, p.freezeTimer - dt);
      if (p.superpowerTimer > 0) p.superpowerTimer = Math.max(0, p.superpowerTimer - dt);
    }
    this.broadcastSnapshot();
  }

  async advanceRoundForPlayer(p, isEarlyFinish = false) {
    if (!p.inMatch) return;
    p.inMatch = false;
    await db.setMatchStatus(p.id, { inActiveMatch: false, pendingDisconnectPenalty: false });
    const clearBonus = (isEarlyFinish ? 250 : 0) + 400 + p.currentRound * 150;
    const updated = await db.applyServerGameplayDelta(p.id, {
      pointsDelta: clearBonus,
      levelDelta: 1,
      eventType: isEarlyFinish ? 'level_clear_early_goals' : 'level_clear_3_rounds'
    });
    if (updated) p.level = updated.level;
    this.io.to(p.socketId).emit('match:level_cleared', {
      level: updated?.level,
      walletPoints: updated?.walletPoints,
      winnerName: p.name
    });
  }

  broadcastSnapshot() {
    const playersPayload = [];
    for (const p of this.players.values()) {
      if (!p.connected) continue;
      playersPayload.push({
        id: p.id, name: p.name, breed: p.breed, outfit: p.outfit, hat: p.hat,
        useCustomColors: p.useCustomColors, customEyeLeft: p.customEyeLeft, customEyeRight: p.customEyeRight,
        x: p.x, y: p.y, z: p.z, rotY: p.rotY, score: p.score,
        isPouncing: p.isPouncing, isLoafing: p.isLoafing,
        napTimer: Number((p.napTimer || 0).toFixed(1)),
        unconsciousTimer: Number((p.unconsciousTimer || 0).toFixed(1)),
        freezeTimer: Number((p.freezeTimer || 0).toFixed(1))
      });
    }
    const botsPayload = [];
    for (const b of this.bots.values()) {
      botsPayload.push({
        id: b.id, name: b.name, breed: b.breed, outfit: b.outfit, hat: b.hat,
        isBot: true, x: b.x, y: b.y, z: b.z, rotY: b.rotY, score: b.score,
        isPouncing: b.isPouncing, unconsciousTimer: Number((b.unconsciousTimer || 0).toFixed(1))
      });
    }
    this.io.to(this.roomId).emit('world:snapshot', {
      t: Date.now(), roomId: this.roomId, region: this.region,
      players: playersPayload, bots: botsPayload
    });
  }
}

export class RoomManager {
  constructor(io) {
    this.io = io;
    this.rooms = new Map();
    this.maxPlayersPerRoom = Number(process.env.MAX_PLAYERS_PER_ROOM) || 16;
    this.reconnectGraceMs = Number(process.env.RECONNECT_GRACE_MS) || 15000;

    VALID_REGIONS.forEach(region => {
      const roomId = `${region}_arena_1`;
      this.rooms.set(roomId, new GameRoom(roomId, region, io, this.maxPlayersPerRoom));
    });

    const tickHz = Number(process.env.SERVER_TICK_RATE_HZ) || 15;
    this.tickInterval = setInterval(() => {
      const dt = 1 / tickHz;
      for (const room of this.rooms.values()) {
        room.tick(dt).catch(err => console.error('[ROOM TICK ERROR]', err));
      }
    }, Math.round(1000 / tickHz));
    this.tickInterval.unref?.();
  }

  stop() {
    if (this.tickInterval) {
      clearInterval(this.tickInterval);
      this.tickInterval = null;
    }
    for (const room of this.rooms.values()) {
      for (const p of room.players.values()) {
        if (p.disconnectTimer) clearTimeout(p.disconnectTimer);
      }
    }
  }

  findAvailableRoom(region, userId) {
    const cleanRegion = VALID_REGIONS.includes(region) ? region : 'global';
    for (const room of this.rooms.values()) {
      if (room.players.has(userId)) {
        if (room.region === cleanRegion) return room;
        room.players.delete(userId);
      }
    }
    for (const room of this.rooms.values()) {
      if (room.region === cleanRegion && room.hasCapacityFor(userId)) return room;
    }
    const newIndex = this.rooms.size + 1;
    const newRoomId = `${cleanRegion}_arena_${newIndex}`;
    const newRoom = new GameRoom(newRoomId, cleanRegion, this.io, this.maxPlayersPerRoom);
    this.rooms.set(newRoomId, newRoom);
    return newRoom;
  }

  handleDisconnect(userId, socketId) {
    for (const room of this.rooms.values()) {
      const p = room.players.get(userId);
      if (p && p.socketId === socketId) {
        p.connected = false;
        p.disconnectTimer = setTimeout(async () => {
          if (p.inMatch) {
            await db.applyServerGameplayDelta(userId, { levelDelta: -1, eventType: 'midgame_disconnect_penalty' });
            await db.setMatchStatus(userId, { inActiveMatch: false, pendingDisconnectPenalty: true });
          }
          room.players.delete(userId);
          this.io.to(room.roomId).emit('player:left', { id: userId });
        }, this.reconnectGraceMs);
        p.disconnectTimer.unref?.();
      }
    }
  }

  getRegionCounts() {
    const counts = { global: 0, asia: 0, na: 0, eu: 0, sa: 0 };
    for (const room of this.rooms.values()) {
      const connectedHumans = Array.from(room.players.values()).filter(p => p.connected).length;
      counts[room.region] = (counts[room.region] || 0) + connectedHumans + room.bots.size;
    }
    return counts;
  }
}
